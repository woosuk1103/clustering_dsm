import numpy as np
import matplotlib.pyplot as plt
import copy

import random

for i in range(10):
    print(random.random())